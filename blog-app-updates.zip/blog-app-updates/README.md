# Blog-App

A full-stack blog platform built with Django and PostgreSQL, featuring tagging, similarity-based search, an email-a-post feature, RSS feeds, and an admin-managed comment system.

## Features

- **Post management** — create, publish, or save posts as drafts via the Django admin (title, slug, body, publish date, status)
- **Tagging** — posts can be tagged and filtered by tag using `django-taggit`
- **Search** — search posts by title using PostgreSQL trigram similarity matching
- **Comments** — readers can comment on published posts; comments can be moderated (active/inactive) from the admin
- **Similar posts** — each post page recommends related posts based on shared tags
- **Share via email** — readers can email a link to any post to a friend, with a personal note
- **RSS feed** — auto-generated feed of the 5 latest published posts, rendered from Markdown
- **Sitemap** — auto-generated XML sitemap of all published posts for SEO
- **Sidebar widgets** — total post count, latest posts, and most-commented posts, via custom Django template tags
- **Pagination** — post list is paginated (3 posts per page)

## Tech Stack

- **Backend:** Django 6.0
- **Database:** PostgreSQL
- **Other libraries:** `django-taggit` (tagging), `python-decouple` (environment config), `markdown` (Markdown rendering for feeds/posts)
- **Frontend:** Django templates, vanilla CSS

## Project Structure

```
Blog-App-main/
├── blog/
│   ├── models.py         # Post, Comment models
│   ├── views.py          # list, detail, search, share, comment views
│   ├── forms.py          # CommentForm, EmailPostForm, SearchForm
│   ├── admin.py          # Django admin config
│   ├── feeds.py          # RSS feed
│   ├── sitemaps.py       # XML sitemap
│   ├── templatetags/     # custom template tags for sidebar widgets
│   ├── templates/blog/   # post list, detail, search, share, comment templates
│   └── static/css/       # stylesheet
├── myproject/
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py / asgi.py
├── manage.py
├── requirements.txt
└── .env.example
```

## Setup & Installation

1. **Clone the repo**
   ```bash
   git clone https://github.com/IezGlitch/Blog-App.git
   cd Blog-App
   ```

2. **Create a virtual environment and install dependencies**
   ```bash
   python -m venv venv
   source venv/bin/activate   # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

3. **Set up PostgreSQL**

   Create a database and note the name, user, and password.

4. **Configure environment variables**

   Copy `.env.example` to `.env` and fill in your own values:
   ```bash
   cp .env.example .env
   ```

5. **Run migrations**
   ```bash
   python manage.py migrate
   ```

6. **Create a superuser** (to access the admin and add posts)
   ```bash
   python manage.py createsuperuser
   ```

7. **Run the development server**
   ```bash
   python manage.py runserver
   ```

   Visit `http://127.0.0.1:8000/` for the blog and `http://127.0.0.1:8000/admin/` to manage posts.

## Environment Variables

See `.env.example` for the required variables:

| Variable | Description |
|---|---|
| `DB_NAME` | PostgreSQL database name |
| `DB_USER` | PostgreSQL username |
| `DB_PASSWORD` | PostgreSQL password |
| `DB_HOST` | Database host (e.g. `localhost`) |
| `EMAIL_HOST_USER` | Gmail address used to send "share post" emails |
| `EMAIL_HOST_PASSWORD` | Gmail App Password (not your regular password) |
| `DEFAULT_FROM_EMAIL` | Default sender name/address for outgoing emails |

**Note:** `.env` is gitignored and should never be committed. Use `.env.example` as a template only.

## Roadmap / Possible Improvements

- Add user registration/authentication for readers (currently only admin-created accounts can author posts)
- Deploy to a live environment (Render/Railway)
- Add image/media support for posts
- Switch full-text search to `SearchVector`/`SearchRank` for multi-field ranked search

## Author

Built by **Pratik Sharma** ([GitHub: IezGlitch](https://github.com/IezGlitch))
